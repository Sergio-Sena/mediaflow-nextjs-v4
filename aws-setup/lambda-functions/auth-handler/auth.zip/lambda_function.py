import json
import hashlib
import hmac
import base64
import boto3
from datetime import datetime, timedelta

dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('mediaflow-users')
secrets_client = boto3.client('secretsmanager', region_name='us-east-1')

def get_jwt_secret():
    try:
        response = secrets_client.get_secret_value(SecretId='midiaflow/jwt-secret')
        return response['SecretString']
    except Exception as e:
        print(f"Error fetching secret: {e}")
        raise Exception("Failed to retrieve JWT secret")

JWT_SECRET = get_jwt_secret()

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def create_jwt(payload, secret):
    """Simple JWT creation without external libraries"""
    header = {"alg": "HS256", "typ": "JWT"}
    
    # Encode header and payload
    header_encoded = base64.urlsafe_b64encode(json.dumps(header).encode()).decode().rstrip('=')
    payload_encoded = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip('=')
    
    # Create signature
    message = f"{header_encoded}.{payload_encoded}"
    signature = hmac.new(secret.encode(), message.encode(), hashlib.sha256).digest()
    signature_encoded = base64.urlsafe_b64encode(signature).decode().rstrip('=')
    
    return f"{message}.{signature_encoded}"

def lambda_handler(event, context):
    try:
        print(f"Login request received: {event['httpMethod']}")
        
        if event['httpMethod'] == 'OPTIONS':
            return cors_response(200, {})
        
        body = json.loads(event.get('body', '{}'))
        email = body.get('email')
        password = body.get('password')
        print(f"Login attempt: {email}")
        
        # Check DynamoDB users
        print("Scanning DynamoDB")
        response = table.scan()
        users = response.get('Items', [])
        print(f"Users found: {len(users)}")
        
        for user in users:
            if user.get('email') == email and user.get('password') == hash_password(password):
                status = user.get('status', 'approved')
                if status == 'pending':
                    print(f"Login blocked - pending: {email}")
                    return cors_response(403, {'success': False, 'error': 'Conta aguardando aprovação do administrador'})
                if status == 'rejected':
                    print(f"Login blocked - rejected: {email}")
                    return cors_response(403, {'success': False, 'error': 'Conta rejeitada pelo administrador'})
                
                s3_prefix = user.get('s3_prefix', '')
                role = user.get('role', 'user')
                payload = {
                    'email': email,
                    'user_id': user['user_id'],
                    's3_prefix': s3_prefix,
                    'role': role,
                    'exp': int((datetime.utcnow() + timedelta(hours=24)).timestamp())
                }
                token = create_jwt(payload, JWT_SECRET)
                print(f"Login successful: {email}, role: {role}, user_id: {user['user_id']}")
                return cors_response(200, {
                    'success': True,
                    'token': token,
                    'user_id': user['user_id'],
                    'user': {
                        'email': email,
                        'name': user.get('name', email),
                        'role': role
                    }
                })
        
        print(f"Login failed - invalid credentials: {email}")
        return cors_response(401, {'success': False, 'error': 'Invalid credentials'})
            
    except Exception as e:
        print(f"Lambda error: {str(e)}")
        return cors_response(500, {'success': False, 'message': str(e)})

def cors_response(status_code, body):
    return {
        'statusCode': status_code,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'POST,OPTIONS'
        },
        'body': json.dumps(body)
    }